import { useState } from 'react';
import { LoginPage } from './components/LoginPage';
import { SignupPage } from './components/SignupPage';
import { UserDashboard } from './components/UserDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { Toaster } from 'sonner@2.0.3';

// Mock accounts
const MOCK_ACCOUNTS = [
  {
    email: 'admin@invoice.com',
    password: 'admin123',
    name: 'Admin',
    role: 'admin'
  },
  {
    email: 'user@invoice.com',
    password: 'user123',
    name: 'Nguyễn Văn A',
    role: 'user'
  }
];

type Page = 'login' | 'signup';
type User = {
  email: string;
  name: string;
  role: 'admin' | 'user';
} | null;

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('login');
  const [currentUser, setCurrentUser] = useState<User>(null);

  const handleLogin = (email: string, password: string) => {
    const account = MOCK_ACCOUNTS.find(
      acc => acc.email === email && acc.password === password
    );

    if (account) {
      setCurrentUser({
        email: account.email,
        name: account.name,
        role: account.role
      });
      return true;
    }
    return false;
  };

  const handleUpdateUser = (name: string, email: string) => {
    if (currentUser) {
      setCurrentUser({
        ...currentUser,
        name,
        email
      });
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentPage('login');
  };

  // If user is logged in, show appropriate dashboard
  if (currentUser) {
    if (currentUser.role === 'admin') {
      return (
        <>
          <Toaster position="top-right" richColors expand={true} />
          <AdminDashboard user={currentUser} onLogout={handleLogout} />
        </>
      );
    } else {
      return (
        <>
          <Toaster position="top-right" richColors expand={true} />
          <UserDashboard user={currentUser} onLogout={handleLogout} onUpdateUser={handleUpdateUser} />
        </>
      );
    }
  }

  // Show login or signup page
  return (
    <>
      <Toaster position="top-right" richColors expand={true} />
      {currentPage === 'login' ? (
        <LoginPage 
          onNavigateToSignup={() => setCurrentPage('signup')}
          onLogin={handleLogin}
        />
      ) : (
        <SignupPage onNavigateToLogin={() => setCurrentPage('login')} />
      )}
    </>
  );
}