
  # Login Registration Interface

  This is a code bundle for Login Registration Interface. The original project is available at https://www.figma.com/design/yFc0y33ttYFAcGSRPP7B8O/Login-Registration-Interface.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  